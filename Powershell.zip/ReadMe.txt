1. open powershell as admin
2. Set-ExecutionPolicy unrestricted [check the refered link for proper policy (http://www.itprotoday.com/management-mobility/running-powershell-scripts-easy-1-2-3)]
3. .\hm2.ps1